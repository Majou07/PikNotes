import cv2
import mediapipe as mp
import pyautogui
import time
import threading
from flask import Flask, jsonify

# =====================
# CONFIGURACIÓN GLOBAL
# =====================
app = Flask(__name__)
running = False
thread = None

pyautogui.FAILSAFE = True
screen_w, screen_h = pyautogui.size()

mp_drawing = mp.solutions.drawing_utils
mp_hands = mp.solutions.hands

FINGER_TIPS = [4, 8, 12, 16, 20]
FINGER_PIPS = [3, 6, 10, 14, 18]


def dedos_extendidos(hand_landmarks):
    lm = hand_landmarks.landmark
    dedos = []

    thumb_extended = lm[4].x > lm[3].x
    dedos.append(thumb_extended)

    for tip_id, pip_id in zip(FINGER_TIPS[1:], FINGER_PIPS[1:]):
        dedos.append(lm[tip_id].y < lm[pip_id].y)

    return dedos


def reconocer_gesto(hand_landmarks):
    pulgar, indice, medio, anular, menique = dedos_extendidos(hand_landmarks)

    if pulgar and not indice and not medio and not anular and not menique:
        return "THUMB_UP"

    if not pulgar and indice and medio and not anular and not menique:
        return "V_SIGN"

    return None


def ejecutar_accion(gesto):
    if gesto == "THUMB_UP":
        pyautogui.press("space")

    elif gesto == "V_SIGN":
        pyautogui.press("m")


def vision_loop():
    global running

    cap = cv2.VideoCapture(0)

    with mp_hands.Hands(
        max_num_hands=1,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5
    ) as hands:

        ultimo_gesto = None
        tiempo_ultimo_gesto = 0
        COOLDOWN = 1.5

        while running:
            ret, frame = cap.read()
            if not ret:
                break

            frame = cv2.flip(frame, 1)
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(rgb)

            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:

                    index_finger = hand_landmarks.landmark[8]
                    x = int(index_finger.x * screen_w)
                    y = int(index_finger.y * screen_h)
                    pyautogui.moveTo(x, y)

                    gesto = reconocer_gesto(hand_landmarks)
                    ahora = time.time()

                    if gesto and (gesto != ultimo_gesto or ahora - tiempo_ultimo_gesto > COOLDOWN):
                        ejecutar_accion(gesto)
                        ultimo_gesto = gesto
                        tiempo_ultimo_gesto = ahora

            cv2.waitKey(1)

    cap.release()
    cv2.destroyAllWindows()


# =====================
# ENDPOINTS
# =====================
@app.route("/start", methods=["POST"])
def start():
    global running, thread

    if not running:
        running = True
        thread = threading.Thread(target=vision_loop)
        thread.start()

    return jsonify({"status": "started"})


@app.route("/stop", methods=["POST"])
def stop():
    global running
    running = False
    return jsonify({"status": "stopped"})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)
