import cv2
import mediapipe as mp
import pyautogui
import time
import threading
import math
from flask import Flask, jsonify

app = Flask(__name__)
running = False
thread = None

pyautogui.FAILSAFE = True
screen_w, screen_h = pyautogui.size()

mp_drawing = mp.solutions.drawing_utils
mp_hands = mp.solutions.hands

FINGER_TIPS = [4, 8, 12, 16, 20]
FINGER_PIPS = [3, 6, 10, 14, 18]

def dedos_extendidos(hand_landmarks):
    lm = hand_landmarks.landmark
    dedos = []
    
    # Pulgar 
    thumb_extended = lm[4].x > lm[3].x
    dedos.append(thumb_extended)

    # Resto de dedos 
    for tip_id, pip_id in zip(FINGER_TIPS[1:], FINGER_PIPS[1:]):
        dedos.append(lm[tip_id].y < lm[pip_id].y)

    return dedos # Pulgar, Indice, Medio, Anular, Meñique

def reconocer_gesto_teclado(dedos):
    
    # Gesto: Puño cerrado: Espacio
    if not any(dedos): 
        return "FIST"

    return None

def ejecutar_accion(gesto):
    if gesto == "V_SIGN":
        pyautogui.press("m")
    elif gesto == "FIST":
        pyautogui.press("space")

def vision_loop():
    global running

    cap = cv2.VideoCapture(0)

    with mp_hands.Hands(
        max_num_hands=1,
        min_detection_confidence=0.7,
        min_tracking_confidence=0.5
    ) as hands:

        ultimo_gesto = None
        tiempo_ultimo_gesto = 0
        COOLDOWN = 1.0
        
        clic_activo = False 
        
        y_anterior_scroll = None
        SCROLL_SENSITIVITY = 1000 

        while running:
            ret, frame = cap.read()
            if not ret:
                break

            frame = cv2.flip(frame, 1)
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(rgb)
            
            h, w, _ = frame.shape

            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    
                    dedos = dedos_extendidos(hand_landmarks)
                    
                    index_tip = hand_landmarks.landmark[8]
                    middle_tip = hand_landmarks.landmark[12]
                    
                    # Calcular distancia entre indice y medio para saber si están "Juntos"
                    ix, iy = int(index_tip.x * w), int(index_tip.y * h)
                    mx, my = int(middle_tip.x * w), int(middle_tip.y * h)
                    distancia_dedos_scroll = math.hypot(mx - ix, my - iy)

                    # --- DETECCIÓN DE MODO SCROLL ---
                    modo_scroll = dedos[1] and dedos[2] and not dedos[3] and not dedos[4] and distancia_dedos_scroll < 60
                    
                    if modo_scroll:
                        cv2.circle(frame, ( (ix+mx)//2, (iy+my)//2 ), 20, (255, 0, 0), cv2.FILLED)
                        cv2.putText(frame, "SCROLL", (ix, iy-30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)

                        current_y = index_tip.y
                        if y_anterior_scroll is not None:
                            # Calcular desplazamiento vertical
                            delta_y = y_anterior_scroll - current_y 
                            
                            if abs(delta_y) > 0.01: 
                                scroll_amount = int(delta_y * SCROLL_SENSITIVITY)
                                pyautogui.scroll(scroll_amount)
                        
                        y_anterior_scroll = current_y
                        
                        continue 

                    else:
                        y_anterior_scroll = None

                    # 1. MOVER EL MOUSE CON EL DEDO
                    control_point = hand_landmarks.landmark[5] 
                    x = int(control_point.x * screen_w)
                    y = int(control_point.y * screen_h)
                    
                    pyautogui.moveTo(x, y)
                    
                    cx, cy = int(control_point.x * w), int(control_point.y * h)
                    cv2.circle(frame, (cx, cy), 10, (255, 255, 0), cv2.FILLED)

                    # 2. DETECTAR CLIC 
                    punta = hand_landmarks.landmark[8]
                    base = hand_landmarks.landmark[5]
                    
                    dist_clic = math.hypot((punta.x - base.x), (punta.y - base.y))
                    umbral_clic = 0.08

                    if dist_clic < umbral_clic:
                        cv2.circle(frame, (cx, cy), 15, (0, 255, 0), 2)
                        if not clic_activo:
                            pyautogui.click()
                            clic_activo = True
                    else:
                        clic_activo = False

                    color_linea = (0, 255, 0) if clic_activo else (0, 0, 255)
                    x_punta, y_punta = int(punta.x * w), int(punta.y * h)
                    x_base, y_base = int(base.x * w), int(base.y * h)
                    cv2.line(frame, (x_punta, y_punta), (x_base, y_base), color_linea, 3)

                    # 3. GESTOS DE TECLADO
                    if distancia_dedos_scroll > 60: 
                        gesto = reconocer_gesto_teclado(dedos)
                        ahora = time.time()
                        
                        if not clic_activo and gesto and (gesto != ultimo_gesto or ahora - tiempo_ultimo_gesto > COOLDOWN):
                            ejecutar_accion(gesto)
                            ultimo_gesto = gesto
                            tiempo_ultimo_gesto = ahora

            cv2.imshow("Hand Control - Scroll & Click", frame)
            
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    cap.release()
    cv2.destroyAllWindows()

@app.route("/start", methods=["POST"])
def start():
    global running, thread
    if not running:
        running = True
        thread = threading.Thread(target=vision_loop)
        thread.start()
    return jsonify({"status": "started"})

@app.route("/stop", methods=["POST"])
def stop():
    global running
    running = False
    return jsonify({"status": "stopped"})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)